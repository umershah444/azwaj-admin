<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateBooksTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('books', function (Blueprint $table) {
            $table->increments('id');
            $table->text('thumbnail')->nullable();
            $table->integer('serial_no')->nullable();
            $table->boolean('status')->nullable();
            $table->integer('suggest_by')->unsigned()->nullable();
            $table->foreign('suggest_by')->references('id')->on('users')->onDelete('cascade');
            $table->text('reference')->nullable();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('books');
    }
}
