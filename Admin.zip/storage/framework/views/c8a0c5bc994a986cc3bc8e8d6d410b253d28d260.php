<?php $__env->startSection('title'); ?>
Success Story / Update - Azwaj
<?php $__env->stopSection(); ?>

<?php $__env->startSection('breadcrumb'); ?>
 <div class="navbar-header">
            <button class="hamburger btn-link no-animation">
                <span class="hamburger-inner"></span>
            </button>
                        <ol class="breadcrumb hidden-xs">
                                    <li class="active">
                        <a href="<?php echo e(route('home')); ?>"><i class="voyager-boat"></i> Dashboard</a>
                    </li>
                      <li class="active">
                        <a href="<?php echo e(route('story.all')); ?>"> Success Story</a>
                    </li>
                                                                                                                                                
                                                    <li>Edit</li>
                        
                                                </ol>                                                                   </ol>
                    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
<style>
    iframe
    {
        height:200px!important;
    } 
</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page_header'); ?>
 <div class="container-fluid">
        <h1 class="page-title">
            <i class="voyager-smile"></i> Edit Success Story
        </h1>
 </div>        
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
                  <div id="voyager-notifications"></div>
                    <div class="page-content container-fluid">
        <form class="form" role="form"
              action="<?php echo e(route('story.update')); ?>"
              method="POST" enctype="multipart/form-data" autocomplete="off">
            <!-- PUT Method if we are editing -->
                  <?php echo e(csrf_field()); ?>


            <div class="row">
                <div class="col-md-8">
                    <div class="panel ">
                    <div class="panel-heading">
                            <h3 class="panel-title"><i class="icon wb-image"></i> Story Details</h3>
                            <div class="panel-actions">
                                <a class="panel-action voyager-angle-down" data-toggle="panel-collapse" aria-hidden="true"></a>
                            </div>
                        </div>
                        <input type='hidden' name='id' value='<?php echo e($story->id); ?>'>  
                        <div class="panel-body">
                            <div class="form-group">
                                <label for="name">Title</label>
                                <textarea  required  class="form-control " cols="5" rows="4" name="title" ><?php echo $story->title;?></textarea>
                                 <?php if($errors->has('title')): ?>
                                    <span class="help-block" >
                                        <strong><?php echo e($errors->first('title')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>

                             <div class="form-group">
                                <label for="name">Description</label>
                                <textarea class="form-control richTextBox" cols="5" rows="4" id="description" name="description" placeholder="Reference"><?php echo $story->description;?></textarea>
                                
                                 <?php if($errors->has('discription')): ?>
                                    <span class="help-block" >
                                        <strong><?php echo e($errors->first('discription')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                            
                            
                            
                            <div class="form-group">
                                <label for="password">Serial No</label>
                                                                <input type="integer" class="form-control" id="serial_no" name="serial_no" value="<?php echo e($story->serial_no); ?>" >
                            <?php if($errors->has('serial_no')): ?>
                                    <span class="help-block" >
                                        <strong><?php echo e($errors->first('serial_no')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>

                            <div class="form-group">
                                    <label for="additional_roles">Status</label>
                                                                        <select
                    class="form-control  select2 "
                    name="status">
                               <?php if($story->status == 1 ): ?>
                                        <option value="1" selected="selected">Published</option>
                                            <option value="0" >Un Published</option>
                                            <?php else: ?>
                                             <option value="1" >Published</option>
                                            <option value="0" selected="selected" >Un Published</option>
                                            <?php endif; ?>
                </select>
                                     <?php if($errors->has('status')): ?>
                                    <span class="help-block" >
                                        <strong><?php echo e($errors->first('status')); ?></strong>
                                    </span>
                                <?php endif; ?>
                                </div>
                                                                          
                        </div>
                    </div>
                </div>

                 
            </div>
                 

            <button type="submit" class="btn btn-primary pull-right save">
                Save
            </button>
        </form>

        
    </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('javascript'); ?>
<?php $__env->stopSection(); ?>




<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>