<?php $__env->startSection('title'); ?>
Banners / Update - Azwaj
<?php $__env->stopSection(); ?>

<?php $__env->startSection('breadcrumb'); ?>
 <div class="navbar-header">
            <button class="hamburger btn-link no-animation">
                <span class="hamburger-inner"></span>
            </button>
                        <ol class="breadcrumb hidden-xs">
                                    <li class="active">
                        <a href="<?php echo e(route('home')); ?>"><i class="voyager-boat"></i> Dashboard</a>
                    </li>
                      <li class="active">
                        <a href="<?php echo e(route('banner.all')); ?>"> Banners</a>
                    </li>
                                                                                                                                                
                                                    <li>Edit</li>
                        
                                                </ol>                                                                   </ol>
                    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page_header'); ?>
 <div class="container-fluid">
        <h1 class="page-title">
            <i class="voyager-images"></i> Edit Banner
        </h1>
 </div>        
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
                  <div id="voyager-notifications"></div>
                    <div class="page-content container-fluid">
        <form class="form" role="form"
              action="<?php echo e(route('banner.update')); ?>"
              method="POST" enctype="multipart/form-data" autocomplete="off">
            <!-- PUT Method if we are editing -->
                  <?php echo e(csrf_field()); ?>


            <div class="row">
                <div class="col-md-8">
                    <div class="panel ">
                     <div class="panel-heading">
                            <h3 class="panel-title"><i class="icon wb-image"></i> Banner Details</h3>
                            <div class="panel-actions">
                                <a class="panel-action voyager-angle-down" data-toggle="panel-collapse" aria-hidden="true"></a>
                            </div>
                        </div>
                        <input type='hidden' name='id' value='<?php echo e($banner->id); ?>'>  
                        <div class="panel-body">
                            <div class="form-group">
                                <label for="name">Title</label>
                                <input type="text" class="form-control" id="title" name="title" placeholder="Title"
                                       value="<?php echo e($banner->title); ?>">
                                 <?php if($errors->has('title')): ?>
                                    <span class="help-block" >
                                        <strong><?php echo e($errors->first('title')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div><br>

                            
                             <div class="form-group">
                                    <label for="additional_roles">Page</label>
                                    <select class="form-control  select2 " name="page" >
                        <?php $__currentLoopData = $pages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        
                        <?php if($banner->page == $page->id): ?>
                        <option value="<?php echo e($page->id); ?>" selected><?php echo e($page->title); ?></option>
                        <?php else: ?>
                        <option value="<?php echo e($page->id); ?>"><?php echo e($page->title); ?></option>
                        <?php endif; ?>
                        
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        
                </select>
                             </div><br>
                            
                           

                            <div class="form-group">
                                <label for="password">Serial No</label>
                                                                <input type="integer" class="form-control" id="serial_no" name="serial_no" value="<?php echo e($banner->serial_no); ?>" >
                            <?php if($errors->has('serial_no')): ?>
                                    <span class="help-block" >
                                        <strong><?php echo e($errors->first('serial_no')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div><br>
                            
                          
                                                        
                                <div class="form-group">
                                    <label for="additional_roles">Status</label>
                                                                        <select
                    class="form-control  select2 "
                    name="status">
                               <?php if($banner->status == 1 ): ?>
                                        <option value="1" selected="selected">Published</option>
                                            <option value="0" >Un Published</option>
                                            <?php else: ?>
                                             <option value="1" >Published</option>
                                            <option value="0" selected="selected" >Un Published</option>
                                            <?php endif; ?>
                </select>
                                     <?php if($errors->has('status')): ?>
                                    <span class="help-block" >
                                        <strong><?php echo e($errors->first('status')); ?></strong>
                                    </span>
                                <?php endif; ?>
                                </div><br>
                                                                          
                        </div>
                    </div>
                 
                </div>

               
                    <div class="col-md-4">
                     <!-- ### IMAGE ### -->
                    <div class="panel panel-bordered panel-primary">
                        <div class="panel-heading">
                            <h3 class="panel-title"><i class="icon wb-image"></i> Banner</h3>
                            <div class="panel-actions">
                                <a class="panel-action voyager-angle-down" data-toggle="panel-collapse" aria-hidden="true"></a>
                            </div>
                        </div>
                        <div class="panel-body">
                            <img src="<?php echo e(asset('upload'.$banner->img_url)); ?>" height="300px" width="300px" >
                                                        <input type="file" name="img_url">
                        </div>
                    </div>
                </div>
            </div>
                  
                  <div class="row">
                <div class="col-md-8">
                <div class="panel panel-bordered panel-info">
                    <div class="panel-heading">
                            <h3 class="panel-title"><i class="icon wb-image"></i>Locales</h3>
                            <div class="panel-actions">
                                <a class="panel-action voyager-angle-down" data-toggle="panel-collapse" aria-hidden="true"></a>
                            </div>
                        </div>
                     <div class="panel-body">
                         
                         
                 <div class="input_fields_wrap" >
                      
                     <button type="button" class="add_field_button btn btn-success fileinput-button " style="width:200px;margin-left: 300px;">Add New Language</button><br><br>
                     
                     <?php $__currentLoopData = $banner->bannerTranslations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bT): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                     
                     <?php if($bT->locale !== 'en'): ?>
                     <div>
                         <div class="form-group">
                                    <label for="additional_roles">Locale</label>
                    <select class="form-control  select2 " name="locales[]"
                            ><option value="" selected disabled>None</option>
                        <?php $__currentLoopData = $locales; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $locale): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($bT->locale == $locale->locale): ?>
                        <option value="<?php echo e($locale->locale); ?>" selected><?php echo e($locale->title); ?></option>
                        <?php else: ?>
                        <option value="<?php echo e($locale->locale); ?>"><?php echo e($locale->title); ?></option>
                        <?php endif; ?>
                        
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        
                </select>
                          </div>
                         
                      <div class="form-group">
                                <label for="name">Title</label>
                                <input type="text" class="form-control" id="title_trans" name="title_trans[]" placeholder="Title"
                                       value="<?php echo e($bT->title); ?>">
                                
                            </div>
                          
                    <a href="#" class="remove_field">Remove</a>

                    <br><br>
                   </div>
                     <?php endif; ?>
                     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </div>
                     </div>
                    </div>
                </div>
                </div>

            <button type="submit" class="btn btn-primary pull-right save">
                Save
            </button>
        </form>

        
    </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('javascript'); ?>

       <script>
       


     
        
        $(document).ready(function() {
    var max_fields      = 10; //maximum input boxes allowed
    var wrapper         = $(".input_fields_wrap"); //Fields wrapper
    var add_button      = $(".add_field_button"); //Add button ID
    
    var x = 1; //initlal text box count
    $(add_button).click(function(e){ //on add input button click
        e.preventDefault();
        if(x < max_fields){ //max input box allowed
            x++; //text box increment
$(wrapper).append('<div><div class="form-group"><label for="additional_roles">Locale</label><select class="form-control  select2" name="locales[]"> <option value="" selected disabled>None</option><?php $__currentLoopData = $locales; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $locale): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><option value="<?php echo e($locale->locale); ?>"><?php echo e($locale->title); ?></option><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></select></div><div class="form-group"><label for="name">Title</label><input type="text" class="form-control" id="title_trans" name="title_trans[]" placeholder="Title" value=""></div><a href="#" class="remove_field">Remove</a><br><br>'); //add input box
       $('.select2').select2();
		}
    });
    
    $(wrapper).on("click",".remove_field", function(e){ //user click on remove text
        e.preventDefault(); $(this).parent('div').remove(); x--;
    });
});
        
    </script>

    

<?php $__env->stopSection(); ?>




<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>