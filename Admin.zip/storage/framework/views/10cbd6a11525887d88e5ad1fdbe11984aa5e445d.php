<?php $__env->startSection('title'); ?>
Books /Preview- Azwaj
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('breadcrumb'); ?>
 <div class="navbar-header">
            <button class="hamburger btn-link no-animation">
                <span class="hamburger-inner"></span>
            </button>
                      <ol class="breadcrumb hidden-xs">
                                    <li class="active">
                        <a href="<?php echo e(route('home')); ?>"><i class="voyager-boat"></i> Dashboard</a>
                    </li><li class="active"><a href="<?php echo e(route('book.all')); ?>">Books</a>
                            </li></ol>                         
                    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page_header'); ?>
                   <h1 class="page-title">
        <i class="voyager-book"></i> <?php echo e($book->title); ?> &nbsp;

    </h1>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
       
<!--iframe  
src="http://docs.google.com/gview?url=<?php echo e(asset('upload'.$book->pdf)); ?>embedded=true" 
style="width:100%; height:700px;" 
frameborder="0"></iframe-->

    <iframe  
src="http://docs.google.com/gview?url=http://islamicmanpower.com/IMP/applicant_form/cvs/100-1.docx&embedded=true" 
style="width:100%; height:700px;" 
frameborder="0"></iframe>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('javascript'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>