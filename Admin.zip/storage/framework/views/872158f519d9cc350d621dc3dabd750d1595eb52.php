<!DOCTYPE html>
<html>
<head>
    <title><?php echo $__env->yieldContent('title'); ?></title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>"/>

    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,700" rel="stylesheet">

    <!-- Favicon -->
    <link rel="shortcut icon" href="<?php echo e(asset('images/logo-icon.png')); ?>" type="image/x-icon">



    <!-- App CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('css/app.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/style.css')); ?>">
<?php 
  function current_page($uri = "/") { 
    return strstr(request()->path(), $uri); 
  } 
?>
  
    <?php echo $__env->yieldContent('css'); ?>
    

    <!-- Few Dynamic Styles -->
    <style type="text/css">
        .voyager .side-menu .navbar-header {
            background:#22A7F0;
            border-color:#22A7F0;
        }
        .widget .btn-primary{
            border-color:#22A7F0;
        }
        .widget .btn-primary:focus, .widget .btn-primary:hover, .widget .btn-primary:active, .widget .btn-primary.active, .widget .btn-primary:active:focus{
            background:#22A7F0;
        }
        .voyager .breadcrumb a{
            color:#22A7F0;
        }
    </style>

   

    <?php echo $__env->yieldContent('head'); ?>
</head>

<body class="voyager">

<div id="voyager-loader">
    
        <img src="<?php echo e(asset('images/logo-icon.png')); ?>" alt="Voyager Loader">
   
</div>

<div class="app-container">
    <div class="fadetoblack visible-xs"></div>
    <div class="row content-container">
       <nav class="navbar navbar-default navbar-fixed-top navbar-top">
    <div class="container-fluid">
        
        <?php echo $__env->yieldContent('breadcrumb'); ?>
        
        <ul class="nav navbar-nav navbar-right">
            <li class="dropdown profile">
                <a href="#" class="dropdown-toggle text-right" data-toggle="dropdown" role="button"
                   aria-expanded="false"><img src="<?php echo e(asset('images/logo-icon.png')); ?>" class="profile-img"> <span
                            class="caret"></span></a>
                <ul class="dropdown-menu dropdown-menu-animated">
                    <li class="profile-img">
                        <?php if(Auth::user()->img_url == null): ?>
                        <img src="<?php echo e(asset('images/default.png')); ?>" class="profile-img">
                        <?php else: ?>
                         <img src="<?php echo e(asset('upload'. Auth::user()->img_url)); ?>" class="profile-img">
                        <?php endif; ?>
                        <div class="profile-body">
                            <h5><?php echo e(Auth::user()->name); ?></h5>
                            <h6><?php echo e(Auth::user()->email); ?></h6>
                        </div>
                    </li>
                     <li class="divider"></li>
                       <li class="class-full-of-rum">
                                                <a href="<?php echo e(route('admin.profile')); ?>" >
                                                        <i class="voyager-person"></i>
                                                        Profile
                        </a>
                                            </li>
                                            <li >
                                                <a href="<?php echo e(route('home')); ?>" target="_blank">
                                                        <i class="voyager-home"></i>
                                                        Home
                        </a>
                                            </li>
                    
                    <li >
                        <form action="<?php echo e(route('logout')); ?>" method="POST">
                            <?php echo e(csrf_field()); ?>

                            <button type="submit" class="btn btn-danger btn-block">
                              <i class="voyager-power"></i>
                                Logout
                            </button>
                        </form>
                       
                    </li>
                   
                    </ul>
                </li>
        
        </ul>
    </div>
</nav>

       <div class="side-menu sidebar-inverse">
    <nav class="navbar navbar-default" role="navigation">
        <div class="side-menu-container">
            <div class="navbar-header">
                <a class="navbar-brand" href="<?php echo e(route('home')); ?>">
                    <div class="logo-icon-container">
                        
                            <img src="<?php echo e(asset('images/logo-icon-light.png')); ?>" alt="Logo Icon">
                        
                    </div>
                    <div class="title">Azwaj </div>
                </a>
            </div><!-- .navbar-header -->

            <div class="panel widget center bgimage"
                 style="background-image:url(<?php echo e(asset('images/bg.jpg')); ?>); background-size: cover; background-position: 0px;">
                <div class="dimmer"></div>
                <div class="panel-content">
                    <?php if(Auth::user()->img_url == null): ?>
                        <img src="<?php echo e(asset('images/default.png')); ?>" class="avatar" alt="<?php echo e(Auth::user()->name); ?> avatar">
                        <?php else: ?>
                         <img src="<?php echo e(asset('upload'. Auth::user()->img_url)); ?>" class="avatar" alt="<?php echo e(Auth::user()->name); ?> avatar">
                        <?php endif; ?>
                    
                    <h4><?php echo e(ucwords(Auth::user()->name)); ?></h4>
                    <p><?php echo e(Auth::user()->email); ?></p>

                    <div style="clear:both"></div>
                </div>
            </div>

        </div>
        
        <ul class="nav navbar-nav">
            <li class="<?php echo e(current_page('admin') ? 'active' : ''); ?>">
        <a href="<?php echo e(route('home')); ?>" target="_self" style="color:">
            <span class="icon voyager-boat"></span>
            <span class="title">Dashboard</span>
        </a>
            </li>
            
             <li class="<?php echo e(current_page('Users') ? 'active' : ''); ?>">
        <a href="<?php echo e(route('users.all')); ?>" target="_self" style="color:">
            <span class="icon voyager-person"></span>
            <span class="title">Users</span>
        </a>
            </li>
            
            <li class="<?php echo e(current_page('Categories') ? 'active' : ''); ?>">
        <a href="<?php echo e(route('category.all')); ?>" target="_self" style="color:">
            <span class="icon voyager-categories"></span>
            <span class="title">Categories</span>
        </a>
            </li>
            
             <li class="<?php echo e(current_page('Video') ? 'active' : ''); ?>">
        <a href="<?php echo e(route('video.all')); ?>" target="_self" style="color:">
            <span class="icon voyager-video"></span>
            <span class="title">Videos</span>
        </a>
            </li>
            
            <li class="<?php echo e(current_page('Article') ? 'active' : ''); ?>">
        <a href="<?php echo e(route('article.all')); ?>" target="_self" style="color:">
            <span class="icon voyager-news"></span>
            <span class="title">Articles</span>
        </a>
            </li>
            
            <li class="<?php echo e(current_page('Book') ? 'active' : ''); ?>">
        <a href="<?php echo e(route('book.all')); ?>" target="_self" style="color:">
            <span class="icon voyager-book"></span>
            <span class="title">Books</span>
        </a>
            </li>
            
            <li class="<?php echo e(current_page('Questionnaire') ? 'active' : ''); ?>">
        <a href="<?php echo e(route('questionnaire.all')); ?>" target="_self" style="color:">
            <span class="icon voyager-bar-chart"></span>
            <span class="title">Questionnaires</span>
        </a>
            </li>
            
            <li class="<?php echo e(current_page('Quotation') ? 'active' : ''); ?>">
        <a href="<?php echo e(route('quotation.all')); ?>" target="_self" style="color:">
            <span class="icon voyager-receipt"></span>
            <span class="title">Quotations</span>
        </a>
            </li>
            
            <li class="<?php echo e(current_page('Success') ? 'active' : ''); ?>">
        <a href="<?php echo e(route('story.all')); ?>" target="_self" style="color:">
            <span class="icon voyager-people"></span>
            <span class="title">Success Stories</span>
        </a>
            </li>
            
             <li class="dropdown">
        <a href="#5-dropdown-element" data-toggle="collapse" aria-expanded="false" target="_self" style="color:">
            <span class="icon voyager-tools"></span>
            <span class="title">Settings</span>
        </a>
                    <div id="5-dropdown-element" class="panel-collapse collapse ">
                <div class="panel-body">
                    <ul class="nav navbar-nav">
                         <li class="<?php echo e(current_page('Banner') ? 'active' : ''); ?>">
        <a href="<?php echo e(route('banner.all')); ?>" target="_self" style="color:">
            <span class="icon voyager-images"></span>
            <span class="title">Banners</span>
        </a>
            </li> 
                    
                    </ul>
                </div>
                    </div>
             </li>
        </ul>

        
    </nav>
</div>

        <script>
            (function(){
                    var appContainer = document.querySelector('.app-container'),
                        sidebar = appContainer.querySelector('.side-menu'),
                        navbar = appContainer.querySelector('nav.navbar.navbar-top'),
                        loader = document.getElementById('voyager-loader'),
                        hamburgerMenu = document.querySelector('.hamburger'),
                        sidebarTransition = sidebar.style.transition,
                        navbarTransition = navbar.style.transition,
                        containerTransition = appContainer.style.transition;

                    sidebar.style.WebkitTransition = sidebar.style.MozTransition = sidebar.style.transition =
                    appContainer.style.WebkitTransition = appContainer.style.MozTransition = appContainer.style.transition =
                    navbar.style.WebkitTransition = navbar.style.MozTransition = navbar.style.transition = 'none';

                    if (window.localStorage && window.localStorage['voyager.stickySidebar'] == 'true') {
                        appContainer.className += ' expanded no-animation';
                        loader.style.left = (sidebar.clientWidth/2)+'px';
                        hamburgerMenu.className += ' is-active no-animation';
                    }

                   navbar.style.WebkitTransition = navbar.style.MozTransition = navbar.style.transition = navbarTransition;
                   sidebar.style.WebkitTransition = sidebar.style.MozTransition = sidebar.style.transition = sidebarTransition;
                   appContainer.style.WebkitTransition = appContainer.style.MozTransition = appContainer.style.transition = containerTransition;
            })();
        </script>
        <!-- Main Content -->
        <div class="container-fluid">
            <div class="side-body padding-top">
                <?php echo $__env->yieldContent('page_header'); ?>
                <div id="voyager-notifications"></div>
                <?php echo $__env->yieldContent('content'); ?>
            </div>
        </div>
    </div>
</div>
<footer class="app-footer">
    <div class="site-footer-right">
        <?php if(rand(1,100) == 100): ?>
            <i class="voyager-rum-1"></i>
        <?php else: ?>
        <a href="http://exagic.com" target="_blank">Exagic</a>
        <?php endif; ?>
       
    </div>
</footer>


<!-- Javascript Libs -->


<script type="text/javascript" src="<?php echo e(asset('js/app.js')); ?>"></script>


<script>
    

    <?php if(Session::has('message')): ?>

    // TODO: change Controllers to use AlertsMessages trait... then remove this
    var alertType = <?php echo json_encode(Session::get('alert-type', 'info')); ?>;
    var alertMessage = <?php echo json_encode(Session::get('message')); ?>;
    var alerter = toastr[alertType];

    if (alerter) {
        alerter(alertMessage);
    } else {
        toastr.error("toastr alert-type " + alertType + " is unknown");
    }

    <?php endif; ?>
</script>
<?php echo $__env->yieldContent('javascript'); ?>



</body>
</html>
