<?php $__env->startSection('title'); ?>
Articles - Azwaj
<?php $__env->stopSection(); ?>

<?php $__env->startSection('breadcrumb'); ?>
 <div class="navbar-header">
            <button class="hamburger btn-link no-animation">
                <span class="hamburger-inner"></span>
            </button>
                        <ol class="breadcrumb hidden-xs">
                                    <li class="active">
                        <a href="<?php echo e(route('home')); ?>"><i class="voyager-boat"></i> Dashboard</a>
                    </li>
                                                                                                                                                
                                                    <li>Articles</li>
                        
                                                </ol>                                                                   </ol>
                    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page_header'); ?>
                    <div class="container-fluid">
        <h1 class="page-title">
            <i class="voyager-news"></i> Articles
        </h1>
                    <a href="<?php echo e(route('article.add')); ?>" class="btn btn-success btn-add-new">
                <i class="voyager-plus"></i> <span>Add New</span>
            </a>
                         <a class="btn btn-danger" id="bulk_delete_btn"><i class="voyager-trash"></i> <span>Bulk Delete</span></a>


<div class="modal modal-danger fade" tabindex="-1" id="bulk_delete_modal" role="dialog">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span
                            aria-hidden="true">&times;</span></button>
                <h4 class="modal-title">
                    <i class="voyager-trash"></i> Are you sure you want to delete <span id="bulk_delete_count"></span> <span id="bulk_delete_display_name"></span>?
                </h4>
            </div>
            <div class="modal-body" id="bulk_delete_modal_body">
            </div>
            <div class="modal-footer">
                <form action="<?php echo e(route('article.bulkDelete')); ?>" id="bulk_delete_form" method="POST">
                   
                     <?php echo e(csrf_field()); ?>

                    <input type="hidden" name="ids" id="bulk_delete_input" value="">
                    <input type="submit" class="btn btn-danger pull-right delete-confirm"
                             value="Yes, Delete These categories">
                </form>
                <button type="button" class="btn btn-default pull-right" data-dismiss="modal">
                    Cancel
                </button>
            </div>
        </div><!-- /.modal-content -->
    </div><!-- /.modal-dialog -->
</div><!-- /.modal -->
                 
<script>
window.onload = function () {
    // Bulk delete selectors
    var $bulkDeleteBtn = $('#bulk_delete_btn');
    var $bulkDeleteModal = $('#bulk_delete_modal');
    var $bulkDeleteCount = $('#bulk_delete_count');
    var $bulkDeleteDisplayName = $('#bulk_delete_display_name');
    var $bulkDeleteInput = $('#bulk_delete_input');
    // Reposition modal to prevent z-index issues
    $bulkDeleteModal.appendTo('body');
    // Bulk delete listener
    $bulkDeleteBtn.click(function () {
        var ids = [];
        var $checkedBoxes = $('#dataTable input[type=checkbox]:checked').not('.select_all');
        var count = $checkedBoxes.length;
        if (count) {
            // Reset input value
            $bulkDeleteInput.val('');
            // Deletion info
            var displayName = count > 1 ? 'Categories' : 'Category';
            displayName = displayName.toLowerCase();
            $bulkDeleteCount.html(count);
            $bulkDeleteDisplayName.html(displayName);
            // Gather IDs
            $.each($checkedBoxes, function () {
                var value = $(this).val();
                ids.push(value);
            })
            // Set input value
            $bulkDeleteInput.val(ids);
            // Show modal
            $bulkDeleteModal.modal('show');
        } else {
            // No row selected
            toastr.warning('You haven&#039;t selected anything to delete');
        }
    });
}
</script>


 </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
                    <div class="page-content browse container-fluid">
    
        <div class="alerts">
            
        </div>
    </div>
        <div class="row">
            <div class="col-md-12">
                <div class="panel panel-bordered">
                    <div class="panel-body">
                                                <div class="table-responsive">
                            <table id="dataTable" class="table table-hover">
                                <thead>
                                    <tr>
                                   <th>
                                                <input type="checkbox" class="select_all">
                                            </th>
                                          
                                            <th style="max-width: 100px">
                            Title </th>
                            <th>
                            Thumbnail
                            </th>
                            <th>
                            Serial no
                            </th>
                            
                             <th>
                            Status
                            </th>
                            <th>
                            Created At
                            </th>
                            
                           
                            <th class="actions text-right">Actions</th>
                            </tr>
                                </thead>
                                <tbody>
                                    
                                    <?php $__currentLoopData = $allArticles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $article): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                 <tr><td>
                                  <input type="checkbox" name="row_id" id="checkbox_<?php echo e($article->id); ?>" value="<?php echo e($article->id); ?>">
                               </td>
                              
                               
                       <td style="max-width: 200px">
                           <?php echo e($article->title); ?>

                       </td>
                      
                       <td>
                      <img src="<?php echo e(asset('upload'.$article->img_url)); ?>" style="width:100px;height: 70px">
                       </td>
                       
                      <td>
                           <?php echo e($article->serial_no); ?>

                       </td>
                      
                      
                       <?php if($article->status == true): ?>
                       <td ><span class="grid-report-item  green">Published</span></td>
                       <?php else: ?>
                        <td ><span class="grid-report-item  red">Un Published</span></td>
                       <?php endif; ?>
                       
                       <td>
                           <?php echo e($article->created_at); ?>

                       </td>
                      
                       <td class="no-sort no-click" id="bread-actions">
                           <a href="javascript:;" title="Delete" class="btn btn-sm btn-danger pull-right delete"data-id="<?php echo e($article->id); ?>" id="delete-<?php echo e($article->id); ?>">
            <i class="voyager-trash"></i> <span class="hidden-xs hidden-sm">Delete</span>
            <a href="<?php echo e(route('article.edit',['id'=>$article->id])); ?>" title="Edit" class="btn btn-sm btn-primary pull-right edit">
            <i class="voyager-edit"></i> <span class="hidden-xs hidden-sm">Edit</span>
        </a>
            <a href="<?php echo e(route('article.detail',['id'=>$article->id])); ?>" title="View" class="btn btn-sm btn-warning pull-right view">
            <i class="voyager-eye"></i> <span class="hidden-xs hidden-sm">View</span>
        </a>
                           </td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                           </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
   <div class="modal modal-danger fade" tabindex="-1" id="delete_modal" role="dialog">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                    <h4 class="modal-title"><i class="voyager-trash"></i> Are you sure you want to delete this category?</h4>
                </div>
                <div class="modal-footer">
                    <form action="" id="delete_form" method="GET">
                        <input type="submit" class="btn btn-danger pull-right delete-confirm" value="Yes, Delete it!">
                    </form>
                    <button type="button" class="btn btn-default pull-right" data-dismiss="modal">Cancel</button>
                </div>
            </div><!-- /.modal-content -->
        </div><!-- /.modal-dialog -->
    </div><!-- /.modal -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('javascript'); ?>

       <script>
        $(document).ready(function () {
                            var table = $('#dataTable').DataTable({"order":[],"language":{"sEmptyTable":"No data available in table","sInfo":"Showing _START_ to _END_ of _TOTAL_ entries","sInfoEmpty":"Showing 0 to 0 of 0 entries","sInfoFiltered":"(filtered from _MAX_ total entries)","sInfoPostFix":"","sInfoThousands":",","sLengthMenu":"Show _MENU_ entries","sLoadingRecords":"Loading...","sProcessing":"Processing...","sSearch":"Search:","sZeroRecords":"No matching records found","oPaginate":{"sFirst":"First","sLast":"Last","sNext":"Next","sPrevious":"Previous"},"oAria":{"sSortAscending":": activate to sort column ascending","sSortDescending":": activate to sort column descending"}},"columnDefs":[{"targets":-1,"searchable":false,"orderable":false}]});
            
                        $('.select_all').on('click', function(e) {
                $('input[name="row_id"]').prop('checked', $(this).prop('checked'));
            });
        });


        var deleteFormAction;
        $('td').on('click', '.delete', function (e) {
            $('#delete_form')[0].action = <?php echo json_encode(url("/Article/Delete/__id")); ?>.replace('__id', $(this).data('id'));
            $('#delete_modal').modal('show');
        });
        
        $('.select_all').on('click', function(e) {
                $('input[name="row_id"]').prop('checked', $(this).prop('checked'));
            });
        
        
    </script>

    

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>