<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class QuestionnaireCategory extends Model
{
    //
}
