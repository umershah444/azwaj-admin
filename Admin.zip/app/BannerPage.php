<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class BannerPage extends Model
{
    ////////////////////PAGE IDS/////////////////
    const Home = 1 ;
    const Define_Yourself = 2 ;
    const Educate_Yourself = 3 ;
    const Define_Yourself_Article = 4 ;
    const Define_Yourself_Book = 5 ;
    const Define_Yourself_Video = 6 ;
}
